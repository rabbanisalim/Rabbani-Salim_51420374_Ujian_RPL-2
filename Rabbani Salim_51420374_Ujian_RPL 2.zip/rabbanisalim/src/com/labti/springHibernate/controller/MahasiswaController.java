package com.labti.springHibernate.controller;
import com.labti.springHibernate.app;
import com.labti.springHibernate.config.MahasiswaTableModel; 
import com.labti.springHibernate.model.Mahasiswa;
import com.labti.springHibernate.view.MahasiswaView;
import com.labti.springHibernate.service.MahasiswaService; 
import java.util.List;
import javax.swing.JOptionPane;

public class MahasiswaController {
    private final MahasiswaView mahasiswaView;
    private MahasiswaTableModel mahasiswaTableModel;
    private List<Mahasiswa> mahasiswas;
    
    public MahasiswaController (MahasiswaView mahasiswaView) { 
        this.mahasiswaView = mahasiswaView;
    }
}
public void tampilData() {
mahasiswas = app.getMahasiswaService ().getMahasiswas (); 
mahasiswaTableModel = new MahasiswaTableModel (mahasiswas); 
this.mahasiswaView.getTabel().setModel (mahasiswaTableModel);
}

public void show() {
    int index = this.mahasiswaView.getTabel ().getSelectedRow(); 
    this.mahasiswaView.getNpm().setText(String.valueOf(
    this.mahasiswaView.getTabel ().getValueAt (index, 0))); 
    this.mahasiswaView.getNama ().setText(String.valueOf( 
    this.mahasiswaView.getTabel().getValueAt (index, 1))); 
    this.mahasiswaView.getKelas ().setText(String.valueOf( 
    this.mahasiswaView.getTabel ().getValueAt (index, 2))); 
    this.mahasiswaView.getAlamat ().setText (String.valueOf( 
    this.mahasiswaView.getTabel().getValueAt (index, 3)));
}