package view;

public class Koneksi {
   public static Connections getConnection(){
       Connection connection = null;
       String driver="com.mysql.jdbc.Driver";
       String url="jdbcmysql//localhost:3306/kampus";
       String user="root";
       String password="";
       if(connection == null){
           try{
               class.forName(driver);
                       connection = Driver
           }
       }
   } 
}
